import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-plumber',
  templateUrl: './single-plumber.component.html',
  styleUrls: ['./single-plumber.component.css']
})
export class SinglePlumberComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
